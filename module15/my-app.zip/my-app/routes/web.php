<?php

use Illuminate\Support\Facades\Route;

use App\Http\Middleware\CheckForm;
use App\Http\Controllers\FormController;
use App\Http\Controllers\MyController;
use App\Http\Middleware\AuthMiddleware;
use App\Http\Controllers\ProductController;
use App\Http\Controllers\ContactController;
use App\Http\Controllers\PostController;

Route::get('/', function () {return view('welcome');});

Route::post('/submit', [FormController::class, 'action'])->middleware([CheckForm::class]);

Route::get('/home', [MyController::class, 'action1']);

Route::get('/dashboard', [MyController::class, 'action2']);

Route::middleware([AuthMiddleware::class])->group(function () {
    Route::get('/profile', [MyController::class, 'action3']);
    Route::get('/settings', [MyController::class, 'action3']);
});

Route::resource('product', ProductController::class);

Route::post('/contact', ContactController::class);

Route::resource('post', PostController::class);

