<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class ContactController extends Controller
{
    
    public function __invoke(Request $request)
    {
        $name = $request->input('name');
        $phn = $request->input('phone');
        $data = array('name' => $name, 'phone' => $phn);

        return response()->json($data, 200);
    }
}
