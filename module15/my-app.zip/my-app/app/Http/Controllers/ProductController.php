<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class ProductController extends Controller
{
    public function index()
    {
        return '<h1>Display a list of all products.</h1>';
    }
    public function create()
    {
        return '<h1>Display the form to create a new product.</h1>';
    }
    public function store(Request $request)
    {
        return '<h1>Store a newly created product.</h1>';
    }
    public function show(string $id)
    {
        return '<h1>Show something</h1>';
    }
    public function edit(string $id)
    {
        return '<h1>Display the form to edit an existing product.</h1>';
    }
    public function update(Request $request, string $id)
    {
        return '<h1>Update the specified product.</h1>';
    }
    public function destroy(string $id)
    {
        return '<h1>Delete the specified product.</h1>';
    }
}
