<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class MyController extends Controller
{
    function action1(Request $request){
        return redirect('/dashboard');
    }
    function action2(Request $request){
        return response()->json('Redirected \home to \dashboard', 302);
    }
    function action3(Request $request){
        return '<h1>Authenticated Profile</h1>';
    }
}
