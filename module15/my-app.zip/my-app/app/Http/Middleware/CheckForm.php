<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

class CheckForm
{
    /**
     * Handle an incoming request.
     *
     * @param  \Closure(\Illuminate\Http\Request): (\Symfony\Component\HttpFoundation\Response)  $next
     */
    public function handle(Request $request, Closure $next): Response
    {
        $name = $request->input('name');
        $email = $request->input('email');
        $password = $request->input('password');

        $is_all_set = isset($name) && isset($email) && isset($password);
        $is_name_length = strlen($name) >= 2;
        $is_password_length = strlen($password) >= 8;
        $is_valid_email = filter_var($email, FILTER_VALIDATE_EMAIL);

        if($is_all_set && $is_name_length && $is_password_length && $is_valid_email){
            return $next($request);
        }else{
            return response()->json("Invalid Input",422);
        }
        //return $next($request);
    }
}
