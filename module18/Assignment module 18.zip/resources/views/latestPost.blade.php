@foreach($latestPosts as $post)
    <div style="width:350px; height:150px; background-color:#8cecb0;">
        <h2>Title: {{ $post->title }}</h2>
        <p>Category: {{ $post->category->name }}</p>
        <p>Conent: {{ $post->details }}</p>
    </div>
@endforeach
