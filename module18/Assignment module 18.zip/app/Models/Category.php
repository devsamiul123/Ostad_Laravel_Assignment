<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

use App\Models\Post;

class Category extends Model
{
    use HasFactory;

    protected $table = 'categories';
    protected $fillable = ['id', 'name', 'created_at', 'updated_at'];

    public function posts()
    {
        return $this->hasMany(Post::class);
    }

    public static function latestPost($categoryId)
    {
        return Post::where('category_id', $categoryId)->latest()->first();
    }

    public static function latestPostForEveryCategory()
    {

        $categoryCount = self::all()->count();
        $latestPosts = [];
        for($i=1; $i<=$categoryCount; $i++){
            $latestPosts[] = Post::where('category_id', $i)->latest()->first();
        }
        return view('latestPost', compact('latestPosts'));
    }
    


}
