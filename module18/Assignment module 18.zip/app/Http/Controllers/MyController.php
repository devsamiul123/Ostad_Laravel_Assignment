<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Models\Post;
use App\Models\Category;

class MyController extends Controller
{
    //

    public function showAllPost() {
        $posts = Post::with('category')->get();
        return view('post', compact('posts'));
    }

    public function postCount(Request $request) {
        $postCount = Post::getPostsCountByCategory($request->category_id);
        return $postCount;
    }

    public function deletePost(Request $request)
    {
        Post::softDeletedPost($request->id);
        return $request->id;
    }

    public function getDeletedPost()
    {
        $softDeletedPosts = Post::getSoftDeletedPosts();
        return $softDeletedPosts;
    }

    public function postByCategory(Request $request) {
        $posts = Post::getPostsByCategory($request->id);
        return view('post', compact('posts'));
    }

    public function latestPostByCategory(Request $request) {
        return Category::latestPost($request->category_id);;
    }

    public function getLatestPostForAllCategory()
    {
        return Category::latestPostForEveryCategory();
    }
    
}

