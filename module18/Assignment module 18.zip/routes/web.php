<?php

use Illuminate\Support\Facades\Route;

use App\Http\Controllers\MyController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

Route::get('/', function () {return view('welcome');});

Route::get('/posts', [MyController::class, 'showAllPost']);

Route::get('/posts/{category_id}', [MyController::class, 'postCount']);

Route::get('/posts/{id}/delete', [MyController::class, 'deletePost']);

Route::get('/posts_deleted', [MyController::class, 'getDeletedPost']);

Route::get('/categories/{id}/posts', [MyController::class, 'postByCategory']);

Route::get('/latest_post/{category_id}', [MyController::class, 'latestPostByCategory']);

Route::get('/latest_post', [MyController::class, 'getLatestPostForAllCategory']);

