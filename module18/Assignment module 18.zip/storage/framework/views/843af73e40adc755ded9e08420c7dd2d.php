<?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div style="width:350px; height:150px; background-color:#eeeeee;">
        <!--<h2>Title: <?php echo e($post->title); ?></h2>-->
        <p>Category: <?php echo e($post->category->name); ?></p>
        <p>Conent: <?php echo e($post->details); ?></p>
    </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php /**PATH C:\wamp64\www\Ostad\Module\18\Assignment\resources\views/post.blade.php ENDPATH**/ ?>