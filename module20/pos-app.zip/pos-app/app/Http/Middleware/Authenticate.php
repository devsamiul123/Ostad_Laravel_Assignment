<?php

namespace App\Http\Middleware;

use Illuminate\Auth\Middleware\Authenticate as Middleware;
use Illuminate\Http\Request;

use Tymon\JWTAuth\Facades\JWTAuth;
use Closure;

class Authenticate extends Middleware
{
    /**
     * Get the path the user should be redirected to when they are not authenticated.
     */
    protected function redirectTo(Request $request): ?string
    {
        return $request->expectsJson() ? null : route('login');
    }


    public function handle($request, Closure $next, ...$guards)
    {
        try {
            $user = JWTAuth::parseToken()->authenticate();
        } catch (Exception $e) {
            // Handle token authentication errors
            return response()->json(['error' => 'Unauthorized'], 401);
        }

        // Store the authenticated user in the request
        $request->merge(['user' => $user]);

        return $next($request);
    }

}
