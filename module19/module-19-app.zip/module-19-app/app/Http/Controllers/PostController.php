<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Models\Post;
use App\Models\Comment;

class PostController extends Controller
{
    public function loadAll()
    {
        $posts = Post::with('comments')->get();

        return view('home', compact('posts'));
    }

    public function show(Post $post)
    {
        return view('post', compact('post'));
    }

    public function store(Request $request, Post $post)
    {
        $validatedData = $request->validate([
            'name' => 'required',
            'comment' => 'required',
        ]);

        $commentData = [
            'post_id' => $post->id,
            'name' => $validatedData['name'],
            'comment' => $validatedData['comment'],
            'published_at' => now(),
        ];

        $comment = Comment::create($commentData);

        return redirect()->back()->with('success', 'Comment added successfully.');
    
    }
}
