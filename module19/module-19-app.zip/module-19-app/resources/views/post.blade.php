@extends('layout')

@section('title', $post->title)

@section('content')
<section>
    <div class="container mx-auto px-4">
        <!-- First Section: Post Details -->
        <div class="mt-8">
          <div class="mb-4 relative" style="background-image: url('https://www.spec-india.com/wp-content/uploads/2023/01/Laravel-Developer.png');
          background-size: cover;
          height: 400px;">
            <div class="absolute bottom-12 left-2 bg-green-500 text-white px-2 py-1 rounded-md text-sm">{{ $post->category }}</div>
            <div class="absolute bottom-2 left-2 bg-gray-800 text-white px-2 py-1 rounded-md text-sm">{{ $post->published_at }}</div>
          </div>
          
          
        </div>
        
        <!-- Second Section: Post Details -->
        <div class="mx-auto w-[800px] my-10">
            <h1 class="text-3xl font-bold mb-2">{{ $post->title }}</h1>
            <div class="flex items-center mb-4">
                <img src="https://w7.pngwing.com/pngs/420/567/png-transparent-avatar-male-man-portrait-avatars-xmas-giveaway-icon.png" alt="Author Image" class="rounded-full mr-2" style="width: 60px">
                <div>
                  <p class="font-bold">Author Name</p>
                  <p>Author Designation</p>
                </div>
              </div>
          <h2 class="text-2xl font-bold mb-2">Post Details</h2>
          <p class="text-gray-700">{{ $post->description }}</p>
        </div>

        <div class="mx-auto w-[800px] my-10">
          <h2 class="text-2xl font-bold mb-4">Comments</h2>
          
          <!-- Comment Form -->
          <form class="mb-4" method="POST" action="{{ route('comment', $post) }}">
            @csrf
            <div class="flex flex-col">
              <label for="name" class="font-bold mb-1">Name</label>
              <input type="text" id="name" name="name" placeholder="Enter your name" class="px-4 py-2 rounded-lg border border-gray-700 focus:border-blue-500 focus:outline-none" required>
            </div>
            
            <div class="flex flex-col mt-2">
              <label for="comment" class="font-bold mb-1">Comment</label>
              <textarea id="comment" name="comment" rows="4" placeholder="Enter your comment" class="px-4 py-2 rounded-lg border border-gray-700 focus:border-blue-500 focus:outline-none" required></textarea>
            </div>
            
            <button type="submit" class="mt-4 bg-blue-500 hover:bg-blue-600 text-white px-4 py-2 rounded-lg">Submit</button>
          </form>
        
          <!-- Comment List -->
          <div class="space-y-4">
            <!-- Comment Item -->
            @foreach($post->comments as $comment)
                <div class="bg-white rounded-lg p-4 shadow">
                    <h3 class="text-lg font-bold mb-2">{{ $comment->name }}</h3>
                    <p class="text-gray-600 mb-2">{{ $comment->published_at }}</p>
                    <p class="text-gray-800">{{ $comment->comment }}</p>
                </div>
            @endforeach
            
            <!-- Add more comment items here -->
          </div>
        </div>
    </div>
</section>
@endsection
