@extends('layout')

@section('title', 'Home')

@section('content')
<section>
    <div class="container mx-auto px-4 pt-7">
        <h1 class="text-3xl font-bold max-w-4xl mx-auto">
            Featured Posts
        </h1>
    </div>

    @foreach($posts as $post)
        <div class="container mx-auto px-4">
            <div class="max-w-4xl mx-auto bg-white shadow-lg rounded-lg overflow-hidden my-8">
                <div class="md:flex">
                <!-- Image -->
                <div class="md:w-1/3">
                <img src="{{ $post->image }}" alt="Post Image" class="w-[300px]">
                </div>
                <!-- Content -->
                <div class="md:w-2/3 px-4 py-4">
                <!-- Title -->
                <h2 class="text-2xl font-bold mb-2 hover:text-red-300"><a href="{{ route('post', $post) }}">{{ $post->title }}</a></h2>
                <!-- Author and Published Date -->
                <p class="text-gray-600 mb-2">
                    <span>{{ $post->author_name }}</span>
                    <span class="mx-2">|</span>
                    <span>{{ $post->published_at }}</span>
                </p>
                <!-- Short Details -->
                <p class="text-gray-800">{{ $post->description }}</p>
                </div>
              </div>
            </div>
        </div>
    @endforeach

</section>
@endsection
