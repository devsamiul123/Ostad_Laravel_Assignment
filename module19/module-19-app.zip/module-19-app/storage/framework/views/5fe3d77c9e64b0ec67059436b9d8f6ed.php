<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $__env->yieldContent('title'); ?></title>
    <link href="<?php echo e(asset('css/output.css')); ?>" rel="stylesheet">
</head>
<body>
    <header class="bg-slate-200 sticky top-0 z-50">
        <div class="container flex items-center justify-between py-4 px-8">
          <div class="flex items-center">
            <img src="https://cdn-icons-png.flaticon.com/512/25/25231.png" alt="Logo" class="w-12">
            <span class="ml-2 text-xl">Your Logo</span>
          </div>
          
          <!-- Navigation Menu -->
          <nav class="flex justify-center flex-grow">
            <ul class="flex space-x-4">
              <li><a href="/" class="hover:text-white">Home</a></li>

              <li><span class="text-gray-300">|</span></li>
              <li><a href="" class="hover:text-white">Post</a></li>

              <li><span class="text-gray-300">|</span></li>
              <li><a href="#" class="hover:text-white">Contact</a></li>
            </ul>
          </nav>
        </div>
    </header>

    <!--------------------
    ---------------------->
    <?php echo $__env->yieldContent('content'); ?>
    <!--------------------
    --------------------->

    <footer class="bg-slate-300 py-4">
        <div class="container mx-auto flex flex-col items-center">
          <!-- Logo -->
          <img src="https://cdn-icons-png.flaticon.com/512/25/25231.png" alt="Footer Logo" class="w-12 h-12 mb-2">
          
          <!-- Copyright -->
          <p class="text-gray-400 text-sm mb-2">
            &copy; Your Website Name | 2023
          </p>
          
          <!-- Social Media Icons -->
          <div class="flex space-x-4">
            <a href="#" target="_blank">
              <img src="https://cdn-icons-png.flaticon.com/512/124/124010.png" alt="Facebook" class="w-[20px]">
            </a>
            <a href="#" target="_blank">
              <img src="https://cdn-icons-png.flaticon.com/512/124/124021.png" alt="Twitter" class="w-[20px]">
            </a>
            <a href="#" target="_blank">
              <img src="https://cdn-icons-png.flaticon.com/512/733/733558.png" alt="Instagram" class="w-[20px]">
            </a>
          </div>
        </div>
    </footer>
</body>
</html><?php /**PATH C:\wamp64\www\Ostad\Module\19\assignment\module-19-app\resources\views/layout.blade.php ENDPATH**/ ?>